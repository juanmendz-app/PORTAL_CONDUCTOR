PORTAL DEL CONDUCTOR — MEJORA DE TRAMOS HORARIOS

- En Control Horario se muestran todos los tramos guardados del día seleccionado.
- Cada tramo se puede editar o eliminar individualmente.
- Corregir un tramo actualiza ese registro existente; no crea un duplicado.
- Tras finalizar una jornada, los campos de entrada manual quedan en 00:00 para poder introducir otro tramo sin arrastrar las horas anteriores.
- Los registros de horas existentes se conservan.

Proyecto fuente ZIP; no es un APK. Recomendado probar primero con una copia de seguridad de los datos.
