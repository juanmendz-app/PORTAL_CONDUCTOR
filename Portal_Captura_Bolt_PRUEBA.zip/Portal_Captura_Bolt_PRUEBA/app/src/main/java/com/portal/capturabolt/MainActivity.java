package com.portal.capturabolt;

import android.content.*;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView status, result;
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String msg=i.getStringExtra("message"); if(msg!=null){ result.setText("Resultado: "+msg); status.setText("Respuesta recibida del servicio."); }
        }
    };
    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.status); result=findViewById(R.id.result);
        registerReceiver(receiver,new IntentFilter("com.portal.capturabolt.RESULT"), Context.RECEIVER_NOT_EXPORTED);
        findViewById(R.id.accessibility).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        findViewById(R.id.capture).setOnClickListener(v -> {
            status.setText("Buscando la ventana de Bolt…");
            startService(new Intent(this, BoltCaptureAccessibilityService.class).setAction("CAPTURE_BOLT"));
        });
    }
    @Override protected void onDestroy(){ unregisterReceiver(receiver); super.onDestroy(); }
}
