package com.portal.capturabolt;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityWindowInfo;
import android.content.Intent;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.List;
import java.util.concurrent.Executor;

public class BoltCaptureAccessibilityService extends AccessibilityService {
    private static final String BOLT_PACKAGE="ee.mtakso.driver";
    private final Executor mainExecutor = command -> getMainExecutor().execute(command);
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && "CAPTURE_BOLT".equals(intent.getAction())) captureBolt();
        return START_NOT_STICKY;
    }
    private void send(String message){ sendBroadcast(new Intent("com.portal.capturabolt.RESULT").putExtra("message",message)); }
    private void captureBolt(){
        if(Build.VERSION.SDK_INT < 34){ send("Android 14 o superior es necesario para capturar solo la ventana."); return; }
        List<AccessibilityWindowInfo> windows=getWindows(); AccessibilityWindowInfo target=null;
        for(AccessibilityWindowInfo w: windows){ if(w!=null && w.getRoot()!=null && BOLT_PACKAGE.equals(String.valueOf(w.getRoot().getPackageName()))){ target=w; break; } }
        if(target==null){ send("No encuentro la ventana de Bolt. Deja Bolt visible y vuelve a pulsar Capturar."); return; }
        final int id=target.getId();
        takeScreenshotOfWindow(id,getMainExecutor(),new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult screenshot){
                HardwareBuffer hb=screenshot.getHardwareBuffer(); Bitmap b=Bitmap.wrapHardwareBuffer(hb,screenshot.getColorSpace());
                if(b==null){ send("No se pudo obtener la imagen de Bolt."); return; }
                runOcr(b); hb.close();
            }
            @Override public void onFailure(int errorCode){ send("Falló la captura de Bolt (código "+errorCode+")."); }
        });
    }
    private void runOcr(Bitmap bitmap){
        InputImage image=InputImage.fromBitmap(bitmap,0);
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener(text -> {
                String raw=text.getText().replace('\n',' ');
                String amount=findAmount(raw);
                send(amount==null ? "OCR OK, pero no encontré un importe. Texto: "+raw : amount+" € | "+raw);
            })
            .addOnFailureListener(e -> send("OCR falló: "+e.getMessage()));
    }
    private String findAmount(String s){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?<!\\d)(\\d{1,4}[,.]\\d{2})(?!\\d)").matcher(s);
        String best=null; while(m.find()){ String x=m.group(1).replace(',','.'); if(best==null) best=x; }
        return best;
    }
}
