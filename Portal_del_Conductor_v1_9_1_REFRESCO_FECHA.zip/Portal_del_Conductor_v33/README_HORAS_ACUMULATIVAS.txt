ACTUALIZACIÓN: REGISTRO ACUMULATIVO DE HORAS

Cambio realizado únicamente en la lógica del Control Horario:
- Cada pulsación de Iniciar jornada y posterior Finalizar jornada guarda un tramo nuevo.
- Los tramos del mismo día ya no se borran ni se sobrescriben.
- Total diario, horas prioritarias/no prioritarias, resumen semanal, mensual e informe suman todos los tramos guardados.
- El registro manual también añade un tramo sin borrar los anteriores.
- Los registros existentes se mantienen; se conserva el formato de datos anterior.

El proyecto se ha revisado con comprobación de sintaxis JavaScript. No se ha probado en el dispositivo Android real.


VERSIÓN 1.4 — CAMBIO DE DÍA A LAS 00:00 LOCALES
Se corrigió el cálculo de fecha para usar el calendario local del dispositivo (en lugar de UTC) y se añadió actualización automática de las pantallas diarias al detectar el cambio de fecha. Al cambiar el día, Control Horario y Facturación diaria pasan al nuevo día con sus registros correspondientes; los datos anteriores no se borran. La pantalla se comprueba cada 15 segundos.
