PORTAL DEL CONDUCTOR v33

Base: v32 reparada.

CAMBIOS DE ESTA VERSION
- Capa de cuenta de acceso con correo electronico o movil + contrasena.
- Creacion de cuenta local para asociar los datos existentes del dispositivo.
- Copia de seguridad local automatica antes de asociar/cambiar la cuenta.
- Opcion "Continuar con mis datos actuales" para no bloquear el acceso ni borrar informacion.
- Cierre de sesion desde Ajustes.
- Se conserva la clave de almacenamiento existente (pdc_v13) para que una actualizacion sobre la misma instalacion conserve los datos locales.
- Se conserva la funcionalidad de calculadora, control horario, facturacion diaria/semanal/mensual, informe, gasolina, ajustes y calculo de nomina mensual.

IMPORTANTE
- NO DESINSTALAR LA VERSION ANTERIOR antes de actualizar, porque los datos locales pertenecen a la instalacion de la aplicacion.
- La sincronizacion real entre dispositivos Android/iPhone requiere conectar esta capa de cuenta a un servicio de nube/backend. Esta v33 deja preparada y protegida la migracion local, pero no inventa un servidor ni unas credenciales que no existen.
- Para una futura version cloud, la misma cuenta podra guardar y recuperar el objeto de datos completo en la nube sin cambiar la logica de las pantallas.


V34.1 — Pago por viaje: al pulsar Bolt/Uber/Cabify/Privados o aeropuerto se solicita Efectivo/Tarjeta; al elegir se guarda automáticamente y la lista muestra el icono de pago. La facturación diaria calcula efectivo/tarjeta automáticamente cuando no existe carga manual del día.


Actualización 1.1 FINAL · Gasolina: listado de cargas por día, editar/eliminar repostajes individuales y eliminar todas las cargas de un día. Se mantiene la compatibilidad con importes de gasolina existentes.

Actualización de recuperación: código interno 344, versión visible 1.1. Basada en la última base anterior al cambio mensual para recuperar el acceso sin tocar los datos.

V1.2 · LECTURA OCR DEL TOTAL DE BOLT
- El botón de cámara toma una foto y trata de leer el importe junto a la etiqueta «Total».
- Si lo detecta, rellena el campo Precio del viaje con el importe para que el conductor lo revise antes de registrar el viaje.
- El OCR se carga desde CDN y descarga el idioma español/inglés al usarlo por primera vez; se requiere conexión a Internet.
- Si no detecta el total con seguridad, muestra un aviso y permite introducir el importe manualmente.
- No se han cambiado los cálculos de viajes, la facturación, gasolina, Control Horario, informes ni autenticación.


VERSIÓN 1.7 — ENCABEZADO DEL VEHÍCULO
Se reemplazó la imagen pequeña del coche por una imagen panorámica optimizada integrada dentro del HTML. Se añadió una única regla CSS final para mantener proporciones, evitar estiramiento y adaptar el encabezado a pantallas pequeñas. No se han cambiado las funciones de cálculo, horas, facturación, informes ni ajustes.
