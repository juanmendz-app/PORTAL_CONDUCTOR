PORTAL DEL CONDUCTOR v33

Base: v32 reparada.

CAMBIOS DE ESTA VERSION
- Capa de cuenta de acceso con correo electronico o movil + contrasena.
- Creacion de cuenta local para asociar los datos existentes del dispositivo.
- Copia de seguridad local automatica antes de asociar/cambiar la cuenta.
- Opcion "Continuar con mis datos actuales" para no bloquear el acceso ni borrar informacion.
- Cierre de sesion desde Ajustes.
- Se conserva la clave de almacenamiento existente (pdc_v13) para que una actualizacion sobre la misma instalacion conserve los datos locales.
- Se conserva la funcionalidad de calculadora, control horario, facturacion diaria/semanal/mensual, informe, gasolina, ajustes y calculo de nomina mensual.

IMPORTANTE
- NO DESINSTALAR LA VERSION ANTERIOR antes de actualizar, porque los datos locales pertenecen a la instalacion de la aplicacion.
- La sincronizacion real entre dispositivos Android/iPhone requiere conectar esta capa de cuenta a un servicio de nube/backend. Esta v33 deja preparada y protegida la migracion local, pero no inventa un servidor ni unas credenciales que no existen.
- Para una futura version cloud, la misma cuenta podra guardar y recuperar el objeto de datos completo en la nube sin cambiar la logica de las pantallas.


V34.1 — Pago por viaje: al pulsar Bolt/Uber/Cabify/Privados o aeropuerto se solicita Efectivo/Tarjeta; al elegir se guarda automáticamente y la lista muestra el icono de pago. La facturación diaria calcula efectivo/tarjeta automáticamente cuando no existe carga manual del día.


Actualización 1.1 FINAL · Gasolina: listado de cargas por día, editar/eliminar repostajes individuales y eliminar todas las cargas de un día. Se mantiene la compatibilidad con importes de gasolina existentes.

Actualización de recuperación: código interno 344, versión visible 1.1. Basada en la última base anterior al cambio mensual para recuperar el acceso sin tocar los datos.
