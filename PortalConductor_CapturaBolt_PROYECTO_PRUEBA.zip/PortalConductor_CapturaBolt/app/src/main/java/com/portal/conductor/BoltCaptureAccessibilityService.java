package com.portal.conductor;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.ScreenshotResult;
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ColorSpace;
import android.hardware.HardwareBuffer;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BoltCaptureAccessibilityService extends AccessibilityService {
    public static volatile BoltCaptureAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final com.google.mlkit.vision.text.TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; recognizer.close(); super.onDestroy(); }

    public void captureBoltScreen() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            toast("La captura de pantalla requiere Android 11 o superior."); return;
        }
        try {
            int displayId = Display.DEFAULT_DISPLAY;
            takeScreenshot(displayId, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    HardwareBuffer buffer = result.getHardwareBuffer();
                    Bitmap hardwareBitmap = Bitmap.wrapHardwareBuffer(buffer, result.getColorSpace());
                    Bitmap bitmap = hardwareBitmap == null ? null : hardwareBitmap.copy(Bitmap.Config.ARGB_8888, false);
                    buffer.close();
                    if (bitmap == null) { toast("No se pudo preparar la captura."); return; }
                    recognize(bitmap);
                }
                @Override public void onFailure(int errorCode) { toast("Android no permitió capturar la pantalla (código " + errorCode + "). Comprueba que el servicio esté activado."); }
            });
        } catch (Exception e) { toast("No se pudo iniciar la captura: " + e.getMessage()); }
    }

    private void recognize(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);
        recognizer.process(image)
            .addOnSuccessListener(text -> {
                String all = text.getText();
                String amount = findAmount(all);
                if (amount == null) {
                    MainActivity.sendFareToPage("", all);
                    toast("Captura realizada, pero no encontré un importe claro. Puedes introducirlo manualmente.");
                } else {
                    MainActivity.sendFareToPage(amount, all);
                    toast("Importe detectado: " + amount + " €");
                }
            })
            .addOnFailureListener(e -> toast("Falló la lectura OCR: " + e.getMessage()))
            .addOnCompleteListener(task -> bitmap.recycle());
    }

    private String findAmount(String text) {
        // Prioriza cantidades que aparecen junto al símbolo de euro; no confirma un importe ambiguo.
        Pattern euroPattern = Pattern.compile("(?i)(?:€\\s*)?([0-9]{1,4}(?:[.,][0-9]{2})?)\\s*€");
        Matcher m = euroPattern.matcher(text);
        String candidate = null;
        while (m.find()) candidate = normalize(m.group(1));
        if (candidate != null) return candidate;
        Pattern labeled = Pattern.compile("(?i)(?:precio|total|importe|ganancia|viaje)[^0-9]{0,18}([0-9]{1,4}[.,][0-9]{2})");
        m = labeled.matcher(text);
        if (m.find()) return normalize(m.group(1));
        return null;
    }
    private String normalize(String raw) { return raw.replace('.', ','); }
    private void toast(String msg) { handler.post(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show()); }
}
