package com.portal.conductor;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private WebView webView;
    public static MainActivity instance;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new CaptureBridge(), "AndroidCaptura");
        setContentView(webView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class CaptureBridge {
        @JavascriptInterface public void capturar() {
            runOnUiThread(() -> {
                if (BoltCaptureAccessibilityService.instance == null) {
                    Toast.makeText(MainActivity.this, "Activa el servicio de captura en Accesibilidad y vuelve a pulsar la cámara.", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                } else {
                    BoltCaptureAccessibilityService.instance.captureBoltScreen();
                }
            });
        }
        @JavascriptInterface public void abrirAjustesAccesibilidad() {
            runOnUiThread(() -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        }
    }

    public static void sendFareToPage(String amount, String recognizedText) {
        MainActivity a = instance;
        if (a == null || a.webView == null) return;
        String safeAmount = amount.replace("\\", "\\\\").replace("'", "\\'");
        String safeText = recognizedText.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
        a.runOnUiThread(() -> a.webView.evaluateJavascript("window.setCapturedFare && window.setCapturedFare('" + safeAmount + "','" + safeText + "')", null));
    }

    @Override protected void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
}
