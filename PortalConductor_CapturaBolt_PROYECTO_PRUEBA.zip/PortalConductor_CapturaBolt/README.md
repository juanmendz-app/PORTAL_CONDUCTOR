# Portal del Conductor — prueba de captura directa de Bolt

Esta carpeta conserva el `index.html` original incluido en `Portal_del_Conductor_v1_2_CAMARA_PRECIO.zip` y añade una capa Android nativa experimental para solicitar una captura de pantalla mediante un servicio de Accesibilidad y ejecutar OCR local con ML Kit.

## Qué incluye
- La interfaz HTML original de Portal del Conductor, con el botón circular azul.
- Puente JavaScript `AndroidCaptura.capturar()`.
- Servicio Android de Accesibilidad que solicita una captura de pantalla cuando el usuario pulsa el botón.
- OCR local y envío del importe reconocido al campo `Precio del viaje (€)`.

## Importante
- Es una **base de prueba**, no una APK validada en el dispositivo todavía.
- El usuario debe activar manualmente el servicio en Ajustes > Accesibilidad.
- La captura depende de la versión de Android, de que el servicio tenga permiso y de las restricciones que Bolt/Android apliquen a la pantalla.
- La detección del importe puede fallar si la pantalla contiene varias cantidades o si el diseño cambia; hay que probarla con una captura real de Bolt y ajustar el OCR sin registrar un precio incorrecto.
- El HTML usa almacenamiento local. No desinstales la aplicación que actualmente funciona ni la sustituyas hasta validar la versión de prueba y conservar los datos.

## Abrir en Codespaces
Abre esta carpeta como proyecto Android/Gradle. Requiere Android SDK y acceso a los repositorios Maven/Google para descargar Android Gradle Plugin y ML Kit. Después sincroniza Gradle y compila la APK de prueba.
